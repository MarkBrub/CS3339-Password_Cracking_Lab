compiled in kali with:

g++ \*.cpp -std=c++20 -pthread -O3 -o main.exe

run with:

./main.exe

The current program was used to find most of the words. Some extra functons were used to find the last few passwords. A large variety of word lists were used and mixed in matched in the existing functions.

All 55 passwords are in cracked.txt in alphebetical order
